const distances = {};

function update(address, qualities) {
    let q = [];

    for (let i = 0; i < qualities.length; i += 1) {
        q.push({
            start: address,
            item: qualities[i],
            mode: 'driving'
        });
    }

    const queries = {
        queries: q
    };

    console.log(queries);

    $.ajax({
        url: '/proximity_multiple',
        type: 'post',
        data: JSON.stringify(queries),
        contentType: "application/json",
        success: response => {
            //actually do stuff here with response
            //parse response

            if (distances[address] === undefined) {
                distances[address] = {};
            }

            for (let i = 0; i < response.data.length; ++i) {
                distances[address][qualities[i]] = response.data[i].rows[0].elements[0].distance.value;
            }

            console.log(response);
        }
    });
}

function safetyUpdate(next) {
    console.log("in");
    let dist = [];


    let address = "500 Memorial Dr, Cambridge, MA 02139";
    let qualities = ["local police station", "local fire station", "local hospital"];
    let q = [];

    for (let i = 0; i < qualities.length; i += 1) {
        q.push({
            start: address,
            item: qualities[i],
            mode: 'driving'
        });
    }

    const queries = {
        queries: q
    };

    console.log(queries);

    $.ajax({
        url: '/proximity_multiple',
        type: 'post',
        data: JSON.stringify(queries),
        contentType: "application/json",
        success: response => {

            //actually do stuff here with response
            //parse response

            for (let i = 0; i < response.data.length; ++i) {
                dist.push(response.data[i].rows[0].elements[0].distance.value);
            }

            console.log(dist[0]);
            console.log(response);

            next(dist);
        }
    });
}


google.charts.load('current', { 'packages': ['bar'] });
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
    let address = "500 Memorial Dr, Cambridge, MA 02139";
    let qualities = ["local police station", "local fire station", "local hospital"];
    update(address, qualities);

    console.log(distances);


    safetyUpdate((dist) => {
        let data = google.visualization.arrayToDataTable([
            ['Amenity', 'House 1', 'House 2', 'House 3'],
            ['Police Station', dist[0], 4, 2],
            ['Fire', dist[1], 14, 2],
            ['Hospital', dist[2], 11, 3]
        ]);

        let options = {
            chart: {
                title: ' '
            },
            bars: 'vertical',
            vAxis: { format: 'decimal' },
            height: 300,
            colors: ['#1b9e77', '#d95f02', '#7570b3']
        };

        let chart = new google.charts.Bar(document.getElementById('chart_div'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
    });
}